package com.example.taskapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
